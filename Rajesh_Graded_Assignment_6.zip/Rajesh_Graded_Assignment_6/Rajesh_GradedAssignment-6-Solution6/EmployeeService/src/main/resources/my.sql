 insert into roles values('1','ADMIN');
 INSERT INTO USERS VALUES('1','$2a$12$nkdHFKltl8X6jkrM6vKDru1RsR0Py4o9KYCoz6fgxChRUXRgS9X.6','user1');
 insert into users_roles values(1,1);